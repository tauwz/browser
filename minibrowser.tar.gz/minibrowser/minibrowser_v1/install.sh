#!/bin/bash
# =============================================================================
# install.sh — Instalador de MiniBrowser 2.3.1 para openSUSE + KDE (QtWebEngine)
#
# Uso:
#   sudo ./install.sh
#
# Qué hace:
#   1. Verifica permisos de root y distro.
#   2. Instala dependencias (PyQt6 WebEngine, con fallback PyQt5).
#   3. Verifica que QtWebEngine realmente carga (no solo está en el RPM).
#   4. Copia minibrowser.py y minibrowser.svg a /opt/minibrowser/.
#   5. Comprueba integridad del script (compila con Python y contiene las
#      funciones nuevas: pestañas, vista dividida y sesión).
#   6. Crea enlace simbólico /usr/bin/minibrowser -> /opt/minibrowser/minibrowser.py
#   7. Instala icono SVG en /usr/share/icons/hicolor/scalable/apps/.
#   8. Crea /usr/share/applications/minibrowser.desktop (versión 2.0).
#   9. Actualiza cachés de iconos y desktop database.
#  10. Test final y resumen.
# =============================================================================

set -euo pipefail

# ---------- helpers ----------
C_ROJO='\033[0;31m'; C_VERDE='\033[0;32m'; C_AMAR='\033[1;33m'; C_AZUL='\033[0;34m'; C_OFF='\033[0m'
log()  { echo -e "${C_AZUL}==>${C_OFF} $*"; }
ok()   { echo -e "    ${C_VERDE}OK${C_OFF}  $*"; }
warn() { echo -e "    ${C_AMAR}AVISO${C_OFF} $*"; }
err()  { echo -e "    ${C_ROJO}ERROR${C_OFF} $*" >&2; }

# ---------- 1. Root ----------
if [[ $EUID -ne 0 ]]; then
    err "Ejecuta con sudo:  sudo ./install.sh"
    exit 1
fi

# ---------- 2. Variables ----------
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_NAME="minibrowser"
INSTALL_DIR="/opt/${APP_NAME}"
BIN_LINK="/usr/bin/${APP_NAME}"
DESKTOP_FILE="/usr/share/applications/${APP_NAME}.desktop"
ICON_DIR_SCALABLE="/usr/share/icons/hicolor/scalable/apps"
ICON_FILE="${ICON_DIR_SCALABLE}/${APP_NAME}.svg"

# ---------- 3. Detectar distro ----------
if [[ -f /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    DISTRO="${ID:-unknown}"
    DISTRO_LIKE="${ID_LIKE:-}"
else
    DISTRO="unknown"
    DISTRO_LIKE=""
fi
log "Distro detectada: ${DISTRO} (${DISTRO_LIKE:-sin ID_LIKE})"

# ---------- 4. Instalar dependencias ----------
install_opensuse() {
    log "Instalando dependencias en openSUSE (zypper)..."
    zypper --non-interactive --quiet refresh || true

    # Primera pasada: PyQt6 (preferido en Tumbleweed)
    log "Intentando PyQt6 + QtWebEngine..."
    if zypper --non-interactive install \
            python3 \
            python3-PyQt6 \
            python3-PyQt6-WebEngine \
            xdotool \
            liberation-fonts \
            hicolor-icon-theme \
            xdg-utils \
            desktop-file-utils; then
        ok "PyQt6 instalado"
    else
        warn "PyQt6 no disponible o falló. Probando PyQt5..."
        zypper --non-interactive install \
                python3 \
                python3-qt5 \
                python3-qtwebengine-qt5 \
                xdotool \
                liberation-fonts \
                hicolor-icon-theme \
                xdg-utils \
                desktop-file-utils
        ok "PyQt5 instalado"
    fi
}

case "${DISTRO}" in
    opensuse*|suse*)
        install_opensuse
        ;;
    *)
        warn "Distro '${DISTRO}' no soportada explícitamente."
        warn "Probando paquetes equivalentes de openSUSE (puede fallar)..."
        install_opensuse
        ;;
esac

# ---------- 5. Verificar que QtWebEngine realmente carga ----------
log "Verificando que QtWebEngine es importable desde Python..."
if python3 -c "import PyQt6.QtWebEngineWidgets" 2>/dev/null; then
    ok "PyQt6.QtWebEngineWidgets se importa correctamente"
    QT_VER="pyqt6"
elif python3 -c "import PyQt5.QtWebEngineWidgets" 2>/dev/null; then
    ok "PyQt5.QtWebEngineWidgets se importa correctamente"
    QT_VER="pyqt5"
else
    err "Ningún QtWebEngine es importable. Revisa los mensajes de zypper arriba."
    err "Posibles causas: repositorio no activo, conflicto de versiones Qt5/Qt6, o falta de libGL."
    exit 1
fi

# ---------- 6. Preparar archivos ----------
if [[ ! -f "${SRC_DIR}/minibrowser.py" ]]; then
    err "No encuentro minibrowser.py junto a este script (${SRC_DIR})."
    err "Coloca minibrowser.py en el mismo directorio que install.sh y vuelve a ejecutar."
    exit 1
fi

log "Copiando archivos a ${INSTALL_DIR}..."
mkdir -p "${INSTALL_DIR}"
install -m 0755 "${SRC_DIR}/minibrowser.py" "${INSTALL_DIR}/minibrowser.py"

# Icono SVG: usar el del usuario si existe, si no generar uno por defecto
generar_icono_svg() {
    local dest="$1"
    cat > "${dest}" <<'SVG'
<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
  <rect x="6"  y="14" width="52" height="40" rx="4" fill="#1f6feb"/>
  <rect x="6"  y="14" width="52" height="8"  rx="4" fill="#0d2a5c"/>
  <circle cx="14" cy="18" r="2" fill="#ff5f56"/>
  <circle cx="22" cy="18" r="2" fill="#ffbd2e"/>
  <circle cx="30" cy="18" r="2" fill="#27c93f"/>
  <path d="M22 38 L32 28 L42 38 L42 48 L22 48 Z" fill="white"/>
  <path d="M22 38 L32 48 L42 38" fill="none" stroke="#1f6feb" stroke-width="1.5"/>
</svg>
SVG
}

if [[ -f "${SRC_DIR}/minibrowser.svg" ]]; then
    install -m 0644 "${SRC_DIR}/minibrowser.svg" "${INSTALL_DIR}/minibrowser.svg"
else
    warn "minibrowser.svg no encontrado. Generando icono por defecto."
    generar_icono_svg "${INSTALL_DIR}/minibrowser.svg"
fi

# ---------- 7. Sanity check: el script debe estar COMPLETO ----------
log "Verificando integridad de minibrowser.py..."
if ! grep -q "app.exec()" "${INSTALL_DIR}/minibrowser.py"; then
    err "minibrowser.py está TRUNCADO: no contiene app.exec()."
    err "La versión anterior tenía este problema y por eso la app no abría."
    exit 1
fi
if ! grep -q "ventana.show()" "${INSTALL_DIR}/minibrowser.py"; then
    err "minibrowser.py no llama ventana.show(). La ventana nunca aparecerá."
    exit 1
fi
# Funciones nuevas de la versión 2.2 (split, flujo con divisorias, apps embebidas y paleta)
for token in QTabBar QSplitter FlujoLayout FlujoZona PanelFlujo PanelApp Paleta dividir fijar_disposicion guardar_sesion cargar_sesion borrar_historial; do
    if ! grep -q "${token}" "${INSTALL_DIR}/minibrowser.py"; then
        err "minibrowser.py no contiene '${token}'."
        err "Parece la versión antigua: usa el minibrowser.py 2.3.1."
        exit 1
    fi
done
# El script debe compilar sin errores de sintaxis
if ! python3 -m py_compile "${INSTALL_DIR}/minibrowser.py" 2>/dev/null; then
    err "minibrowser.py tiene errores de sintaxis. Revisa la versión del script."
    exit 1
fi
# Versión 2.3.1 (arreglo de arranque + selftest)
if ! grep -q "selftest" "${INSTALL_DIR}/minibrowser.py"; then
    err "minibrowser.py no es la versión 2.3.1 (sin selftest)."
    err "Usa el minibrowser.py más reciente: corrige el arranque con PyQt5."
    exit 1
fi
ok "Script íntegro (v2.3.1): pestañas, split, flujo con divisorias, apps embebidas, paleta y sesión presentes"

# ---------- 7b. Smoke test: ¿arranca de verdad? ----------
# Ejecuta la app SIN pantalla (offscreen) y sale solo. Si algo falla al
# arrancar (imports, Qt, WebEngine) se detecta AQUÍ y no «la app no abre».
log "Prueba de arranque real (offscreen, --selftest)..."
if QT_QPA_PLATFORM=offscreen QTWEBENGINE_DISABLE_SANDBOX=1 timeout 60 \
        python3 "${INSTALL_DIR}/minibrowser.py" --selftest 2>"${INSTALL_DIR}/selftest.log"; then
    ok "Arranque verificado: la ventana se construye sin errores"
else
    err "EL SCRIPT FALLA AL ARRANCAR. Contenido de ${INSTALL_DIR}/selftest.log:"
    cat "${INSTALL_DIR}/selftest.log" >&2 || true
    err "No se instala: corrige el problema antes de continuar."
    exit 1
fi

# ---------- 8. Enlace simbólico /usr/bin/minibrowser ----------
log "Creando enlace ${BIN_LINK} -> ${INSTALL_DIR}/minibrowser.py..."
ln -sf "${INSTALL_DIR}/minibrowser.py" "${BIN_LINK}"
chmod +x "${INSTALL_DIR}/minibrowser.py"
ok "Binario accesible como: minibrowser"

# ---------- 9. Icono en el tema hicolor ----------
log "Instalando icono en tema hicolor..."
mkdir -p "${ICON_DIR_SCALABLE}"
install -m 0644 "${INSTALL_DIR}/minibrowser.svg" "${ICON_FILE}"

# ---------- 10. Archivo .desktop ----------
log "Creando entrada de menú KDE: ${DESKTOP_FILE}"
cat > "${DESKTOP_FILE}" <<DESKTOP_EOF
[Desktop Entry]
Type=Application
Version=2.3.1
Name=MiniBrowser
Name[es]=MiniBrowser
GenericName=Navegador web privado
GenericName[es]=Navegador web privado
Comment=Navegador privado QtWebEngine: pestañas, split, flujo, apps embebidas y paleta de comandos
Comment[es]=Navegador privado QtWebEngine: pestañas, split, flujo, apps embebidas y paleta de comandos
Exec=${BIN_LINK}
Icon=${APP_NAME}
Terminal=false
Categories=Network;WebBrowser;Qt;
Keywords=web;browser;private;incognito;internet;tabs;split;flow;panes;palette;terminal;
StartupNotify=true
StartupWMClass=${APP_NAME}
DESKTOP_EOF
chmod 0644 "${DESKTOP_FILE}"

# ---------- 11. Actualizar bases de datos ----------
log "Actualizando cachés de iconos y entradas .desktop..."
gtk-update-icon-cache -f -t /usr/share/icons/hicolor 2>/dev/null || warn "gtk-update-icon-cache no disponible (no crítico)."
update-desktop-database /usr/share/applications 2>/dev/null || warn "update-desktop-database no disponible (no crítico)."

# ---------- 12. Test final ----------
log "Resumen de instalación:"
echo
test -x "${INSTALL_DIR}/minibrowser.py"  && ok "Script:  ${INSTALL_DIR}/minibrowser.py" || err "Script no instalado"
test -L "${BIN_LINK}"                    && ok "Enlace:  ${BIN_LINK} -> $(readlink -f "${BIN_LINK}")" || err "Enlace no creado"
test -f "${ICON_FILE}"                   && ok "Icono:   ${ICON_FILE}" || err "Icono no instalado"
test -f "${DESKTOP_FILE}"                && ok "Desktop: ${DESKTOP_FILE}" || err "Desktop entry no creado"
echo
ok "QtWebEngine activo vía: ${QT_VER}"
echo

log "Para abrir MiniBrowser:"
echo "   - Desde terminal:        minibrowser"
echo "   - Desde menú KDE:        busca 'MiniBrowser' en KRunner (Alt+Espacio)"
echo "   - Para depurar fallos:   QT_LOGGING_RULES='qt.qpa.*=true' minibrowser 2>&1 | head -50"
echo
log "Novedades v2.3.1: CORREGIDO el arranque con PyQt5 (QAction) · si algo falla, el error queda en ~/.local/state/minibrowser/error.log · comandos de división tmux-style (Ctrl+Shift+H derecha, Ctrl+Shift+V debajo) que abren un panel nuevo listo para cargar · divisorias arrastrables en flujo · navegación con Ctrl · paneles de aplicación (X11 + xdotool) · paleta de comandos (Ctrl+K) · abre los paneles como se dejaron"
echo
ok "Instalación completada."

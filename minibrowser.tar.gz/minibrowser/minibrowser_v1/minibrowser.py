#!/usr/bin/env python3
# MiniBrowser 2.3.1 — navegador privado para openSUSE + KDE (QtWebEngine)
#
# Corregido en 2.3.1 (la app no abría tras la última instalación):
#   - El fallback PyQt5 importaba QAction desde PyQt5.QtGui, pero en Qt5
#     QAction vive en QtWidgets: ImportError al arrancar y ninguna ventana.
#   - En el menú se hacía m.addAction(submenu) tras addMenu(); en PyQt6 no
#     existe addAction(QMenu) y reventaba el arranque (TypeError). addMenu()
#     ya inserta el submenú: eliminado.
#   - Ahora todo fallo de arranque se escribe en
#     ~/.local/state/minibrowser/error.log (además de stderr).
#   - Nuevo: minibrowser --selftest (lo usa install.sh para probar el
#     arranque real, sin pantalla).
#
# Novedades respecto a la versión 2.2:
#   - Comandos de división (tmux-style): abren un panel NUEVO junto al panel
#     activo, a la derecha/izquierda o encima/debajo, y dejan la barra de
#     direcciones enfocada para cargar algo al instante.
#     Ctrl+Shift+H divide a la derecha · Ctrl+Shift+V divide debajo; el resto
#     en el menú ☰ -> «Dividir y abrir panel» y en la paleta (Ctrl+K),
#     incluida la variante con aplicación embebida (solo X11).
#
# Novedades respecto a la versión 2.1:
#   - Líneas divisorias entre paneles de la disposición flujo, con cursor de
#     arrastre: arrastra la línea para cambiar el ancho de los paneles de la
#     fila (o el alto de las filas). Es como un QSplitter "fluido".
#   - Navegación con Ctrl: Ctrl+Tab / Ctrl+Shift+Tab panel siguiente/anterior,
#     Ctrl+1..9 salta al panel N (Ctrl+0 al último) y Ctrl+Alt+flechas mueve
#     el foco al panel más cercano en esa dirección (funciona en todos los
#     modos: normal, split h/v y flujo).
#   - Paneles de aplicación: embebe programas externos (terminal, kwrite,
#     btop, tu editor...) en un panel. Solo sesión X11 (KDE: "Plasma (X11)"),
#     usando xdotool para localizar la ventana del programa e incrustarla
#     con QWindow.fromWinId + createWindowContainer.
#   - Paleta de comandos tipo KRunner (Ctrl+K): escribe para buscar acciones
#     ("flujo", "borrar historial", "aplicación"...), o una URL/búsqueda y
#     Enter para abrirla.
#
# Disposiciones de los paneles (menú ☰ -> Disposición de los paneles):
#   n  Pestaña única (normal): se ve solo la pestaña activa.
#   h  Secuencial horizontal: n paneles redimensionables en fila (QSplitter).
#   v  Secuencial vertical:   n paneles redimensionables en columna (QSplitter).
#   f  Flujo: paneles en secuencia con salto de línea automático (flex-wrap),
#      con líneas divisorias arrastrables entre paneles y entre filas.
#
# La sesión guardada incluye disposición, paneles (URL o comando de la app)
# y anchos; solo guarda URLs e interfaz, nunca cookies/historial/caché.
#
# Atajos: Ctrl+T nueva pestaña · Ctrl+W cerrar panel · Ctrl+L barra direcciones
#         Ctrl+K paleta de comandos · Ctrl+Tab / Ctrl+1..9 navegar paneles
#         Ctrl+Shift+H dividir a la derecha · Ctrl+Shift+V dividir debajo
#         Alt+Left / Alt+Right atrás/adelante · F5 / Ctrl+R recargar
#         Ctrl+Shift+D alternar dividida · Ctrl+Shift+Del borrar historial
#         Ctrl+Q salir

import json, os, re, shutil, subprocess, sys, time
from urllib.parse import quote_plus

try:  # PyQt6 (Tumbleweed: python3-PyQt6-WebEngine)
    from PyQt6.QtCore import Qt, QUrl, QEvent, QTimer, QRect, QSize, QProcess
    from PyQt6.QtGui import (QAction, QIcon, QKeySequence, QWindow, QPainter,
                             QPalette)
    from PyQt6.QtWidgets import (QApplication, QMainWindow, QToolBar, QLineEdit,
                                 QStyle, QTabBar, QToolButton, QSplitter,
                                 QMenu, QWidget, QSizePolicy, QLayout,
                                 QStackedLayout, QFrame, QLabel, QDialog,
                                 QListWidget, QListWidgetItem,
                                 QVBoxLayout, QHBoxLayout)
    from PyQt6.QtWebEngineCore import QWebEngineProfile, QWebEnginePage
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    QT6 = True
except ImportError:  # openSUSE: python3-qtwebengine-qt5
    # OJO: en Qt5 QAction vive en QtWidgets (solo en Qt6 se movió a QtGui).
    # Importarla aquí desde QtGui provocaba un ImportError AL ARRANCAR y la
    # app moría sin abrir ninguna ventana («ejecuto y no abre nada»).
    from PyQt5.QtCore import Qt, QUrl, QEvent, QTimer, QRect, QSize, QProcess
    from PyQt5.QtGui import QIcon, QKeySequence, QWindow, QPainter, QPalette
    from PyQt5.QtWidgets import (QApplication, QMainWindow, QToolBar, QLineEdit,
                                 QStyle, QTabBar, QToolButton, QSplitter,
                                 QMenu, QWidget, QSizePolicy, QLayout,
                                 QStackedLayout, QFrame, QLabel, QDialog,
                                 QListWidget, QListWidgetItem,
                                 QVBoxLayout, QHBoxLayout, QAction)
    from PyQt5.QtWebEngineCore import QWebEngineProfile, QWebEnginePage
    from PyQt5.QtWebEngineWidgets import QWebEngineView
    QT6 = False

SEARCH = "https://duckduckgo.com/?q="
INICIO = "https://duckduckgo.com"

# Poner a False si no se quiere guardar/restaurar la sesión de paneles.
# (El archivo solo guarda URLs, comandos y disposición; ver guardar_sesion.)
GUARDAR_SESION = True

# Disposición "flujo": ancho mínimo de un panel (px) antes de saltar de línea.
MIN_ANCHO = 280
MIN_ALTO = 160
# Arrastre de divisorias: grosor de la zona sensible (px) y tamaño mínimo
# que un panel/fila puede tener tras arrastrar.
TOL = 5
MIN_PANELO = 80

try:  # enums con ámbito (estilo PyQt6)
    ELIDE = Qt.TextElideMode.ElideRight
    ORIENT_H = Qt.Orientation.Horizontal
    ORIENT_V = Qt.Orientation.Vertical
    FOCUS_IN = QEvent.Type.FocusIn
    TAM_EXP = QSizePolicy.Policy.Expanding
    TAM_PREF = QSizePolicy.Policy.Preferred
    POPUP = QToolButton.ToolButtonPopupMode.InstantPopup
    FRAME_PANEL = QFrame.Shape.StyledPanel
    CURSOR_H = Qt.CursorShape.SizeHorCursor
    CURSOR_V = Qt.CursorShape.SizeVerCursor
    CURSOR_A = Qt.CursorShape.ArrowCursor
    FOCO_FUERTE = Qt.FocusPolicy.StrongFocus
    ALINEA_C = Qt.AlignmentFlag.AlignCenter
    PALETTE_MID = QPalette.ColorRole.Mid
    PALETTE_HL = QPalette.ColorRole.Highlight
    ROL_DATO = Qt.ItemDataRole.UserRole
    VENTANA_PALETA = Qt.WindowType.Dialog | Qt.WindowType.FramelessWindowHint
except AttributeError:  # enums planos (estilo PyQt5)
    ELIDE = Qt.ElideRight
    ORIENT_H = Qt.Horizontal
    ORIENT_V = Qt.Vertical
    FOCUS_IN = QEvent.FocusIn
    TAM_EXP = QSizePolicy.Expanding
    TAM_PREF = QSizePolicy.Preferred
    POPUP = QToolButton.InstantPopup
    FRAME_PANEL = QFrame.StyledPanel
    CURSOR_H = Qt.SizeHorCursor
    CURSOR_V = Qt.SizeVerCursor
    CURSOR_A = Qt.ArrowCursor
    FOCO_FUERTE = Qt.StrongFocus
    ALINEA_C = Qt.AlignCenter
    PALETTE_MID = QPalette.Mid
    PALETTE_HL = QPalette.Highlight
    ROL_DATO = Qt.UserRole
    VENTANA_PALETA = Qt.Dialog | Qt.FramelessWindowHint

try:
    SP = QStyle.StandardPixmap          # PyQt6
except AttributeError:
    SP = QStyle                         # PyQt5


def icono():
    """Icono de la app: tema hicolor primero; si no, SVG junto al script.
    Nota: usamos realpath(__file__) porque /usr/bin/minibrowser es un
    symlink a /opt/minibrowser/minibrowser.py, y __file__ por defecto
    reporta la ruta del symlink (no la del destino)."""
    ruta_script = os.path.realpath(__file__)
    candidatos = [
        os.path.join(os.path.dirname(ruta_script), "minibrowser.svg"),
        "/opt/minibrowser/minibrowser.svg",
        "/usr/share/icons/hicolor/scalable/apps/minibrowser.svg",
    ]
    local = next((p for p in candidatos if os.path.isfile(p)), None)
    if local:
        return QIcon.fromTheme("minibrowser", QIcon(local))
    return QIcon.fromTheme("minibrowser")


def ruta_sesion():
    """Ruta del archivo de sesión (~/.local/state/minibrowser/sesion.json)."""
    base = os.environ.get("XDG_STATE_HOME") or os.path.expanduser("~/.local/state")
    return os.path.join(base, "minibrowser", "sesion.json")


class Vista(QWebEngineView):
    """Vista web de un panel. Los enlaces target=_blank abren un panel nuevo
    (mismo perfil, misma ventana)."""
    def __init__(self, ventana):
        super().__init__(None)
        self.ventana = ventana
        self.setPage(QWebEnginePage(ventana.perfil, self))

    def createWindow(self, _tipo):
        pan = self.ventana.nueva_pestana()
        return pan.vista


# ---------------------------------------------------------------------------
# Paneles de aplicación: embeber ventanas de programas externos (solo X11).
# ---------------------------------------------------------------------------

class PanelApp(QWidget):
    """Lanza un comando y busca su ventana con xdotool; al encontrarla la
    incrusta en el panel con QWindow.fromWinId + createWindowContainer.
    Requiere sesión X11 (KDE: elegir "Plasma (X11)" al iniciar sesión)."""

    def __init__(self, ventana, comando):
        super().__init__()
        self.ventana = ventana
        self.comando = comando
        self.titulo = comando
        self.proceso = None
        self.cont = None          # QWidget contenedor de la ventana embebida
        self.win = None           # QWindow embebida
        self.intentos = 0
        self._pan = None          # Pestaña asociada (la fija la Ventana)
        self.setFocusPolicy(FOCO_FUERTE)

        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        self.estado = QLabel()
        self.estado.setWordWrap(True)
        self.estado.setAlignment(ALINEA_C)
        v.addWidget(self.estado, 1)

        plataforma = QApplication.platformName()   # xcb / wayland / eglfs...
        if plataforma != "xcb":
            self.estado.setText(
                "Embeber aplicaciones requiere una sesión X11.\n"
                "En KDE: cierra sesión y elige «Plasma (X11)».")
        elif shutil.which("xdotool") is None:
            self.estado.setText(
                f"Falta «xdotool» para localizar la ventana de «{comando}».\n"
                "Instálalo con:  sudo zypper install xdotool")
        else:
            self.estado.setText(f"Buscando la ventana de «{comando}»…")
            self.proceso = QProcess(self)
            self.proceso.start("/bin/sh", ["-c", comando])
            self.timer = QTimer(self)
            self.timer.setInterval(400)
            self.timer.timeout.connect(self._buscar_ventana)
            QTimer.singleShot(600, self.timer.start)

    def _buscar_ventana(self):
        self.intentos += 1
        if self.intentos > 40:            # ~16 s buscando
            self.timer.stop()
            self.estado.setText(f"No encontré la ventana de «{self.comando}».")
            return
        if self.proceso is None or self.proceso.processId() <= 0:
            self.timer.stop()
            self.estado.setText(f"El programa «{self.comando}» terminó.")
            return
        pid = str(self.proceso.processId())
        ids = self._xdotool(["search", "--all", "--onlyvisible", "--pid", pid])
        if not ids:
            # Fallback: por clase, con el primer token del comando.
            base = os.path.basename(self.comando.split()[0])
            ids = self._xdotool(["search", "--onlyvisible", "--class", base])
        if not ids:
            ids = self._xdotool(["search", "--onlyvisible", "--classname", base])
        if not ids:
            return
        self.timer.stop()
        self._embeber(int(ids[-1]))

    def _xdotool(self, args):
        try:
            r = subprocess.run(["xdotool"] + args, capture_output=True,
                               text=True, timeout=2)
            return [l for l in r.stdout.split() if l.strip().isdigit()]
        except Exception:
            return []

    def _embeber(self, winid):
        try:
            self.win = QWindow.fromWinId(winid)
            self.cont = QWidget.createWindowContainer(self.win, self)
            self.cont.setFocusPolicy(FOCO_FUERTE)
        except Exception:
            self.estado.setText(f"No pude incrustar la ventana {winid}.")
            return
        self.layout().removeWidget(self.estado)
        self.estado.deleteLater()
        self.estado = None
        self.layout().addWidget(self.cont, 1)
        self.cont.installEventFilter(self.ventana)   # foco → panel activo
        self.win.titleChanged.connect(self._titulo_win)
        self._titulo_win(self.win.title())

    def _titulo_win(self, t):
        self.titulo = t or self.comando
        if self._pan is not None:
            self.ventana._actualizar_titulo(self._pan)

    def cerrar(self):
        """Al cerrar el panel, terminar el programa embebido."""
        if self.proceso is not None:
            self.proceso.terminate()
            QTimer.singleShot(1500, self.proceso.kill)


class Pestaña:
    """Registro lógico de un panel: o vista web, o aplicación embebida."""
    def __init__(self, contenedor, vista=None, app=None):
        self.contenedor = contenedor   # PanelFlujo (con cabecera)
        self.vista = vista             # Vista (web) o None
        self.app = app                 # PanelApp o None

    @property
    def titulo(self):
        if self.vista is not None:
            return self.vista.title()
        if self.app is not None:
            return self.app.titulo
        return "Nueva pestaña"

    @property
    def direccion(self):
        if self.vista is not None:
            return self.vista.url().toString()
        if self.app is not None:
            return "app://" + self.app.comando
        return ""

    def enfocar(self):
        if self.vista is not None:
            self.vista.setFocus()
        elif self.app is not None:
            self.app.setFocus()


class FlujoLayout(QLayout):
    """Layout tipo flex-wrap: coloca los paneles en secuencia y los que no
    caben saltan a una línea nueva cuando la ventana se estrecha. Cada panel
    (PanelFlujo) lleva un atributo "peso" (ancho relativo, como flex-basis en
    %) y hay un ancho mínimo absoluto; las filas se escalan para llenar el
    ancho. Las alturas de fila pueden fijarse arrastrando las divisorias
    horizontales (alturas_fila: lista de fracciones) o se reparten a partes
    iguales. Guarda la última geometría calculada (ult_filas / ult_widgets)
    para que FlujoZona pueda dibujar y golpear las divisorias."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.items = []
        self.esp = 6                       # separación entre paneles (gap)
        self.alturas_fila = None           # None => reparto igualitario
        self.ult_filas = None              # [[QRect, ...], ...] última colocación
        self.ult_widgets = None            # [[QWidget, ...], ...] paralelo
        self.setContentsMargins(6, 6, 6, 6)

    # --- API obligatoria de QLayout ---
    def addItem(self, item):
        self.items.append(item)

    def count(self):
        return len(self.items)

    def itemAt(self, i):
        return self.items[i] if 0 <= i < len(self.items) else None

    def takeAt(self, i):
        return self.items.pop(i) if 0 <= i < len(self.items) else None

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        m = self.contentsMargins()
        w = MIN_ANCHO
        for it in self.items:
            wd = it.widget()
            if wd is not None:
                w = max(w, it.minimumSize().width())
        return QSize(w + m.left() + m.right(), MIN_ALTO + m.top() + m.bottom())

    def expandingDirections(self):
        return Qt.Orientations(ORIENT_H | ORIENT_V)

    # --- colocación tipo flex-wrap ---
    def setGeometry(self, rect):
        super().setGeometry(rect)
        m = self.contentsMargins()
        W = rect.width() - m.left() - m.right()
        H = rect.height() - m.top() - m.bottom()
        visibles = [it for it in self.items
                    if it.widget() is not None and it.widget().isVisible()]
        if W <= 0 or H <= 0 or not visibles:
            self.ult_filas = self.ult_widgets = None
            return

        # Ancho efectivo de cada panel: su peso relativo, con piso en MIN_ANCHO.
        anchos = [max(float(MIN_ANCHO), getattr(it.widget(), "peso", 0.5) * W)
                  for it in visibles]

        # Reparto en filas (wrap): cuando el acumulado no cabe, nueva línea.
        filas, actual, suma = [], [], 0.0
        for it, a in zip(visibles, anchos):
            if actual and suma + a > W + 0.01:
                filas.append(actual)
                actual, suma = [], 0.0
            actual.append((it, a))
            suma += a
        if actual:
            filas.append(actual)

        # Alturas de fila: fracciones guardadas (por arrastre) o reparto igual.
        n = len(filas)
        if self.alturas_fila and len(self.alturas_fila) == n:
            total = sum(self.alturas_fila) or 1.0
            altos = [max(float(MIN_PANELO), f * H) for f in self.alturas_fila]
        else:
            altos = [H / n] * n

        y = m.top()
        filas_rect, filas_wid = [], []
        for fila, alto_fila in zip(filas, altos):
            suma_f = sum(a for _it, a in fila)
            escala = ((W - self.esp * (len(fila) - 1)) / suma_f) if suma_f > 0 else 1.0
            x = m.left()
            rects, wids = [], []
            for it, a in fila:
                w = max(1.0, a * escala)
                q = QRect(int(round(x)), int(round(y)),
                          int(round(w)), int(round(alto_fila)))
                it.setGeometry(q)
                rects.append(q)
                wids.append(it.widget())
                x += w + self.esp
            filas_rect.append(rects)
            filas_wid.append(wids)
            y += alto_fila
        self.ult_filas = filas_rect
        self.ult_widgets = filas_wid


class FlujoZona(QWidget):
    """Página de la disposición flujo: contiene el FlujoLayout, dibuja las
    líneas divisorias entre paneles (y entre filas) y permite arrastrarlas
    para redimensionar, con cursor de arrastre."""

    def __init__(self, ventana):
        super().__init__()
        self.ventana = ventana
        self.setLayout(FlujoLayout())
        self._drag = None
        self.setMouseTracking(True)       # cursor de arrastre al pasar por encima

    # ---------- utilidades ----------

    def _lay(self):
        return self.layout()

    def _divisor_en(self, pos):
        """Devuelve ('v', fila, k, x) para divisoria vertical entre paneles
        k y k+1 de la fila dada, ('h', fila, y) entre filas, o None."""
        filas = self._lay().ult_filas
        if not filas:
            return None
        for r, fila in enumerate(filas):
            for k in range(len(fila) - 1):
                a, b = fila[k], fila[k + 1]
                xm = (a.right() + b.left()) // 2
                if (abs(pos.x() - xm) <= TOL
                        and a.top() - TOL <= pos.y() <= a.bottom() + TOL):
                    return ("v", r, k, xm)
        for r in range(len(filas) - 1):
            f1, f2 = filas[r], filas[r + 1]
            ym = (f1[0].bottom() + f2[0].top()) // 2
            x0 = min(q.left() for q in f1 + f2)
            x1 = max(q.right() for q in f1 + f2)
            if (abs(pos.y() - ym) <= TOL
                    and x0 - TOL <= pos.x() <= x1 + TOL):
                return ("h", r, ym)
        return None

    # ---------- eventos ----------

    def paintEvent(self, _ev):
        filas = self._lay().ult_filas
        if not filas:
            return
        p = QPainter(self)
        normal = self.palette().color(PALETTE_MID)
        activo = self.palette().color(PALETTE_HL)
        d = self._drag
        for r, fila in enumerate(filas):
            for k in range(len(fila) - 1):
                a, b = fila[k], fila[k + 1]
                xm = (a.right() + b.left()) // 2
                y0, y1 = min(a.top(), b.top()), max(a.bottom(), b.bottom())
                color = (activo if (d and d[0] == "v" and d[1] == r and d[2] == k)
                         else normal)
                p.fillRect(xm - 1, y0, 2, y1 - y0 + 1, color)
        for r in range(len(filas) - 1):
            f1, f2 = filas[r], filas[r + 1]
            ym = (f1[0].bottom() + f2[0].top()) // 2
            x0 = min(q.left() for q in f1 + f2)
            x1 = max(q.right() for q in f1 + f2)
            color = activo if (d and d[0] == "h" and d[1] == r) else normal
            p.fillRect(x0, ym - 1, x1 - x0 + 1, 2, color)

    def mousePressEvent(self, ev):
        d = self._divisor_en(ev.position().toPoint() if hasattr(ev, "position")
                             else ev.pos())
        if d is None:
            self._drag = None
            return
        lay = self._lay()
        if d[0] == "v":
            _, r, k, xm = d
            fila, wids = lay.ult_filas[r], lay.ult_widgets[r]
            a, b = fila[k], fila[k + 1]
            self._drag = {"t": "v", "r": r, "k": k, "f0": xm,
                          "wa": a.width(), "wb": b.width(),
                          "pa": wids[k].peso, "pb": wids[k + 1].peso,
                          "cur": CURSOR_H}
        else:
            _, r, ym = d
            filas = lay.ult_filas
            ha, hb = filas[r][0].height(), filas[r + 1][0].height()
            self._drag = {"t": "h", "r": r, "f0": ym,
                          "ha": ha, "hb": hb, "cur": CURSOR_V}
        self.setCursor(self._drag["cur"])

    def mouseMoveEvent(self, ev):
        pos = ev.position().toPoint() if hasattr(ev, "position") else ev.pos()
        if self._drag is None:
            d = self._divisor_en(pos)
            self.setCursor(CURSOR_A if d is None
                           else (CURSOR_H if d[0] == "v" else CURSOR_V))
            return
        lay = self._lay()
        drag = self._drag
        if drag["t"] == "v":
            dx = pos.x() - drag["f0"]
            dx = max(MIN_PANELO - drag["wa"],
                     min(drag["wb"] - MIN_PANELO, dx))
            fila_w = lay.ult_widgets[drag["r"]]
            wa = drag["wa"] if drag["wa"] > 0 else 1.0
            wb = drag["wb"] if drag["wb"] > 0 else 1.0
            fila_w[drag["k"]].peso = max(0.05, drag["pa"] * (wa + dx) / wa)
            fila_w[drag["k"] + 1].peso = max(0.05, drag["pb"] * (wb - dx) / wb)
        else:
            dy = pos.y() - drag["f0"]
            dy = max(MIN_PANELO - drag["ha"],
                     min(drag["hb"] - MIN_PANELO, dy))
            filas = lay.ult_filas
            n = len(filas)
            fracs = (list(lay.alturas_fila) if lay.alturas_fila
                     and len(lay.alturas_fila) == n else [1.0 / n] * n)
            ha, hb = drag["ha"] or 1.0, drag["hb"] or 1.0
            fracs[drag["r"]] = fracs[drag["r"]] * (ha + dy) / ha
            fracs[drag["r"] + 1] = fracs[drag["r"] + 1] * (hb - dy) / hb
            total = sum(fracs) or 1.0
            lay.alturas_fila = [f / total for f in fracs]
        lay.update()

    def mouseReleaseEvent(self, _ev):
        if self._drag is not None:
            self._drag = None
            self.unsetCursor()
            self.ventana.programar_guardado()


class PanelFlujo(QFrame):
    """Contenedor de un panel: cabecera fina con título + menú propio
    (ancho del panel en % y cerrar), y debajo el contenido (web o app)."""

    def __init__(self, ventana, contenido, titulo="Nueva pestaña"):
        super().__init__()
        self.ventana = ventana
        self.contenido = contenido
        self.peso = 0.5                    # flex-basis: 50 % del ancho de fila
        self.setFrameShape(FRAME_PANEL)
        self.setLineWidth(1)

        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        cab = QWidget()
        h = QHBoxLayout(cab)
        h.setContentsMargins(6, 2, 2, 2)
        h.setSpacing(4)
        self.titulo = QLabel(titulo)
        f = self.titulo.font()
        f.setPointSize(max(7, f.pointSize() - 1))
        self.titulo.setFont(f)
        h.addWidget(self.titulo, 1)

        self.btn = QToolButton()
        self.btn.setText("▾")
        self.btn.setAutoRaise(True)
        self.btn.setToolTip("Opciones del panel: ancho, cerrar")
        self.btn.setPopupMode(POPUP)
        self.btn.setMenu(self._menu())
        h.addWidget(self.btn)

        v.addWidget(cab)
        v.addWidget(contenido, 1)

    def _menu(self):
        m = QMenu(self)
        sub = m.addMenu("Ancho del panel")
        for etiqueta, peso in (("25 %", 0.25), ("33 %", 1 / 3), ("50 %", 0.5),
                               ("66 %", 2 / 3), ("75 %", 0.75), ("100 %", 1.0)):
            a = QAction(etiqueta, self)
            a.triggered.connect(lambda _, p=peso: self.ventana.fijar_peso(self, p))
            sub.addAction(a)
        m.addSeparator()
        a_cerrar = QAction("Cerrar panel", self)
        a_cerrar.triggered.connect(self._cerrar)
        m.addAction(a_cerrar)
        return m

    def _cerrar(self):
        for i, pan in enumerate(self.ventana.pestañas):
            if pan.contenedor is self:
                self.ventana.cerrar_pestana(i)
                return


class Paleta(QDialog):
    """Paleta de comandos tipo KRunner: busca acciones por texto y también
    permite abrir URLs o búsquedas escribiéndolas y pulsando Enter."""

    def __init__(self, ventana, acciones):
        super().__init__(ventana)
        self.ventana = ventana
        self.acciones = acciones           # list[(texto, callback)]
        self.setWindowFlags(VENTANA_PALETA)
        v = QVBoxLayout(self)
        v.setContentsMargins(8, 8, 8, 8)
        v.setSpacing(6)
        self.entrada = QLineEdit()
        self.entrada.setPlaceholderText(
            "Comando, URL o búsqueda…  (p. ej.: flujo · aplicación · borrar historial)")
        self.lista = QListWidget()
        v.addWidget(self.entrada)
        v.addWidget(self.lista, 1)
        self.entrada.textEdited.connect(self._filtrar)
        self.entrada.returnPressed.connect(self._ejecutar_actual)
        self.lista.itemActivated.connect(lambda _it: self._ejecutar_actual())
        self._filtrar()

    def _filtrar(self, _t=None):
        texto = self.entrada.text().strip()
        self.lista.clear()
        if texto:
            it = QListWidgetItem(f"Buscar o abrir:  «{texto}»")
            it.setData(ROL_DATO, lambda: self.ventana._abrir_texto(texto))
            self.lista.addItem(it)
        bajo = texto.lower()
        for t, cb in self.acciones:
            if not bajo or bajo in t.lower():
                it = QListWidgetItem(t)
                it.setData(ROL_DATO, cb)
                self.lista.addItem(it)
        if self.lista.count():
            self.lista.setCurrentRow(0)

    def _ejecutar_actual(self):
        it = self.lista.currentItem()
        if it is None:
            self.reject()
            return
        cb = it.data(ROL_DATO)
        self.accept()
        if cb:
            cb()


class Ventana(QMainWindow):
    def __init__(self, perfil):
        super().__init__()
        self.perfil = perfil
        self.pestañas = []        # list[Pestaña], en el mismo orden que self.tabs
        self.historial = []       # URLs visitadas en esta sesión (solo RAM)
        self.disposicion = "n"    # n normal · h fila · v columna · f flujo
        self.ultima_div = "h"     # última disposición dividida usada
        self.ruta_sesion = ruta_sesion()
        self.resize(1100, 760)
        self.setWindowTitle("MiniBrowser — privado")

        # --- barra de herramientas: [←][→][⟳][dirección][pestañas][+][␣][menú] ---
        tb = QToolBar()
        tb.setMovable(False)
        self.addToolBar(tb)

        atras = tb.addAction(self.style().standardIcon(SP.SP_ArrowBack), "Atrás")
        atras.setShortcut(QKeySequence("Alt+Left"))
        atras.triggered.connect(lambda: self._navegar("back"))

        adelante = tb.addAction(self.style().standardIcon(SP.SP_ArrowForward), "Adelante")
        adelante.setShortcut(QKeySequence("Alt+Right"))
        adelante.triggered.connect(lambda: self._navegar("forward"))

        recargar = tb.addAction(self.style().standardIcon(SP.SP_BrowserReload), "Recargar")
        recargar.setShortcuts([QKeySequence("F5"), QKeySequence("Ctrl+R")])
        recargar.triggered.connect(lambda: self._navegar("reload"))

        self.dir = QLineEdit()
        self.dir.setClearButtonEnabled(True)
        self.dir.setPlaceholderText("Busca o escribe una dirección")
        tb.addWidget(self.dir)
        self.dir.returnPressed.connect(lambda: self._abrir_texto(self.dir.text()))

        enfocar = QAction("Ir a la barra de direcciones", self)
        enfocar.setShortcut(QKeySequence("Ctrl+L"))
        enfocar.triggered.connect(lambda: (self.dir.setFocus(), self.dir.selectAll()))
        self.addAction(enfocar)

        # --- pestañas: misma fila, a la derecha de la barra de direcciones ---
        self.tabs = QTabBar()
        self.tabs.setTabsClosable(True)
        self.tabs.setMovable(True)
        self.tabs.setExpanding(False)
        self.tabs.setUsesScrollButtons(True)
        self.tabs.setElideMode(ELIDE)
        tb.addWidget(self.tabs)
        self.tabs.currentChanged.connect(self._cambio_pestana)
        self.tabs.tabCloseRequested.connect(self.cerrar_pestana)
        self.tabs.tabMoved.connect(self._pestana_movida)

        btn_nueva = QToolButton()
        btn_nueva.setText("+")
        btn_nueva.setAutoRaise(True)
        btn_nueva.setToolTip("Nueva pestaña (Ctrl+T)")
        btn_nueva.clicked.connect(lambda: self.nueva_pestana())
        tb.addWidget(btn_nueva)

        espaciador = QWidget()          # empuja el menú hasta la derecha
        espaciador.setSizePolicy(TAM_EXP, TAM_PREF)
        tb.addWidget(espaciador)

        # --- menú, esquina superior derecha ---
        btn_menu = QToolButton()
        btn_menu.setText("☰")
        btn_menu.setAutoRaise(True)
        btn_menu.setToolTip("Menú")
        btn_menu.setPopupMode(POPUP)
        btn_menu.setMenu(self._crear_menu())
        tb.addWidget(btn_menu)

        # --- zona central: apilador con dos páginas ---
        #   página 0: QSplitter (disposiciones n/h/v)
        #   página 1: FlujoZona con FlujoLayout (disposición f, tipo flex-wrap)
        self.host = QWidget()
        self.apilado_host = QStackedLayout(self.host)

        self.splitter = QSplitter()
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(4)
        self.splitter.setOrientation(ORIENT_H)

        self.flujo = FlujoZona(self)

        self.apilado_host.addWidget(self.splitter)
        self.apilado_host.addWidget(self.flujo)
        self.setCentralWidget(self.host)

        self._crear_atajos()

        self.statusBar().showMessage(
            "Perfil off-the-record: cookies, historial y caché solo en RAM "
            "· Ctrl+K paleta de comandos", 8000)

        # Guardado de sesión con retardo (evita escribir en cada evento).
        self._guardar_timer = QTimer(self)
        self._guardar_timer.setSingleShot(True)
        self._guardar_timer.timeout.connect(self.guardar_sesion)

        sesion = cargar_sesion(self.ruta_sesion)
        if sesion:
            # "Abrir como se dejó": disposición, paneles (con su ancho) y activa.
            self.fijar_disposicion(sesion["disposicion"])
            activa = max(0, min(sesion["activa"], len(sesion["paneles"]) - 1))
            for i, e in enumerate(sesion["paneles"]):
                if e["tipo"] == "app":
                    self.nueva_pestana_app(e["comando"], peso=e["peso"],
                                           activar=(i == activa))
                else:
                    self.nueva_pestana(e["url"], peso=e["peso"],
                                       activar=(i == activa))
            QTimer.singleShot(0, self._igualar_tamanos)
        else:
            self.nueva_pestana(INICIO)

    # ---------- atajos de navegación con Ctrl ----------

    def _crear_atajos(self):
        def acc(texto, teclas, slot):
            a = QAction(texto, self)
            if isinstance(teclas, str):
                teclas = [teclas]
            a.setShortcuts([QKeySequence(t) for t in teclas])
            a.triggered.connect(slot)
            self.addAction(a)

        acc("Panel siguiente", "Ctrl+Tab", self._panel_siguiente)
        acc("Panel anterior", "Ctrl+Shift+Tab", self._panel_anterior)
        for k in range(1, 10):
            acc(f"Panel {k}", f"Ctrl+{k}",
                lambda _, n=k - 1: self._saltar_panel(n))
        acc("Último panel", "Ctrl+0",
            lambda: self._saltar_panel(len(self.pestañas) - 1))
        acc("Foco a la izquierda", "Ctrl+Alt+Left",
            lambda: self._foco_direccion(-1, 0))
        acc("Foco a la derecha", "Ctrl+Alt+Right",
            lambda: self._foco_direccion(1, 0))
        acc("Foco arriba", "Ctrl+Alt+Up",
            lambda: self._foco_direccion(0, -1))
        acc("Foco abajo", "Ctrl+Alt+Down",
            lambda: self._foco_direccion(0, 1))
        acc("Paleta de comandos", ["Ctrl+K", "Alt+F2"], self.abrir_paleta)
        acc("Dividir a la derecha", "Ctrl+Shift+H", lambda: self.dividir("der"))
        acc("Dividir debajo", "Ctrl+Shift+V", lambda: self.dividir("aba"))

    def _panel_siguiente(self):
        n = len(self.pestañas)
        if n:
            self._saltar_panel((self.tabs.currentIndex() + 1) % n)

    def _panel_anterior(self):
        n = len(self.pestañas)
        if n:
            self._saltar_panel((self.tabs.currentIndex() - 1) % n)

    def _saltar_panel(self, i):
        if 0 <= i < len(self.pestañas):
            self.tabs.setCurrentIndex(i)
            self.pestañas[i].enfocar()

    def _foco_direccion(self, dx, dy):
        """Mueve el foco al panel más cercano en la dirección indicada
        (según la geometría de los paneles). Funciona en split y flujo."""
        i = self.tabs.currentIndex()
        if not (0 <= i < len(self.pestañas)):
            return
        if self.disposicion == "n":
            # En modo pestaña única no hay vecinos: usar siguiente/anterior.
            self._panel_siguiente() if dx > 0 else self._panel_anterior()
            return
        base = self.pestañas[i].contenedor
        cb = base.mapTo(self, base.rect().center())
        mejor, dist_mejor = None, None
        for j, pan in enumerate(self.pestañas):
            if j == i or not pan.contenedor.isVisible():
                continue
            cj = pan.contenedor.mapTo(self, pan.contenedor.rect().center())
            if dx > 0 and cj.x() <= cb.x() + 8:      continue
            if dx < 0 and cj.x() >= cb.x() - 8:      continue
            if dy > 0 and cj.y() <= cb.y() + 8:      continue
            if dy < 0 and cj.y() >= cb.y() - 8:      continue
            dist = abs(cj.x() - cb.x()) + abs(cj.y() - cb.y())
            if dist_mejor is None or dist < dist_mejor:
                mejor, dist_mejor = j, dist
        if mejor is not None:
            self._saltar_panel(mejor)

    # ---------- menú ----------

    def _crear_menu(self):
        m = QMenu(self)

        a_nueva = QAction("Nueva pestaña", self)
        a_nueva.setShortcut(QKeySequence("Ctrl+T"))
        a_nueva.triggered.connect(lambda: self.nueva_pestana())
        m.addAction(a_nueva)

        a_app = QAction("Nuevo panel de aplicación…", self)
        a_app.triggered.connect(lambda: self._pedir_app())
        m.addAction(a_app)

        sub2 = m.addMenu("Dividir y abrir panel")
        for lado, txt, atajo in (("der", "A la derecha del activo", "Ctrl+Shift+H"),
                                 ("aba", "Debajo del activo", "Ctrl+Shift+V"),
                                 ("izq", "A la izquierda del activo", None),
                                 ("arr", "Encima del activo", None)):
            a = QAction(txt, self)
            if atajo:
                a.setShortcut(QKeySequence(atajo))
            a.triggered.connect(lambda _, l=lado: self.dividir(l))
            sub2.addAction(a)
        sub2.addSeparator()
        a_app_split = QAction("…con aplicación embebida", self)
        a_app_split.triggered.connect(lambda: self._pedir_app("der"))
        sub2.addAction(a_app_split)
        # NOTA: addMenu() ya inserta el submenú en m; no hace falta (y en
        # PyQt6 revienta: no existe addAction(QMenu)) volver a añadirlo.

        a_paleta = QAction("Paleta de comandos…", self)
        a_paleta.setShortcut(QKeySequence("Ctrl+K"))
        a_paleta.triggered.connect(self.abrir_paleta)
        m.addAction(a_paleta)

        a_cerrar = QAction("Cerrar pestaña", self)
        a_cerrar.setShortcut(QKeySequence("Ctrl+W"))
        a_cerrar.triggered.connect(lambda: self.cerrar_pestana(self.tabs.currentIndex()))
        m.addAction(a_cerrar)

        m.addSeparator()

        a_toggle = QAction("Alternar vista dividida", self)
        a_toggle.setShortcut(QKeySequence("Ctrl+Shift+D"))
        a_toggle.triggered.connect(self.alternar_division)
        m.addAction(a_toggle)

        sub = m.addMenu("Disposición de los paneles")
        self.acc_disp = {}
        for d, txt in (("n", "Pestaña única (normal)"),
                       ("h", "Secuencial horizontal — paneles en fila"),
                       ("v", "Secuencial vertical — paneles en columna"),
                       ("f", "Flujo — salto de línea automático (flex-wrap)")):
            a = QAction(txt, self)
            a.setCheckable(True)
            a.setChecked(d == self.disposicion)
            a.triggered.connect(lambda _, dd=d: self.fijar_disposicion(dd))
            sub.addAction(a)
            self.acc_disp[d] = a

        m.addSeparator()

        a_hist = QAction("Borrar historial", self)
        a_hist.setShortcut(QKeySequence("Ctrl+Shift+Del"))
        a_hist.triggered.connect(self.borrar_historial)
        m.addAction(a_hist)

        a_cookies = QAction("Borrar cookies y caché", self)
        a_cookies.triggered.connect(self.borrar_cookies_cache)
        m.addAction(a_cookies)

        a_sesion = QAction("Borrar sesión guardada", self)
        a_sesion.triggered.connect(self.borrar_sesion_guardada)
        m.addAction(a_sesion)

        m.addSeparator()

        a_salir = QAction("Salir", self)
        a_salir.setShortcut(QKeySequence("Ctrl+Q"))
        a_salir.triggered.connect(self.close)
        m.addAction(a_salir)

        return m

    # ---------- pestañas / paneles ----------

    def _panel_activo(self):
        i = self.tabs.currentIndex()
        if 0 <= i < len(self.pestañas):
            return self.pestañas[i]
        return self.pestañas[0] if self.pestañas else None

    def _registrar_panel(self, pan, url=None, peso=None, activar=True, pos=None):
        if peso:
            pan.contenedor.peso = max(0.1, min(1.0, float(peso)))
        if pos is None:
            self.pestañas.append(pan)
            self.tabs.addTab(pan.titulo or "Nueva pestaña")
        else:
            pos = max(0, min(int(pos), len(self.pestañas)))
            self.pestañas.insert(pos, pan)
            self.tabs.insertTab(pos, pan.titulo or "Nueva pestaña")
        v = pan.vista
        if v is not None:
            v.installEventFilter(self)
            v.titleChanged.connect(lambda _t, p=pan: self._actualizar_titulo(p))
            v.urlChanged.connect(self._url_cambiada)
            v.urlChanged.connect(lambda u: self._registrar_historial(u))
        # El contenedor va al destino según la disposición actual.
        if self.disposicion == "f":
            self.flujo.layout().addWidget(pan.contenedor)
        else:
            self.splitter.addWidget(pan.contenedor)
        if activar:
            self.tabs.setCurrentIndex(self.pestañas.index(pan))
        if url:
            pan.vista.load(QUrl(url))
        self.flujo.layout().alturas_fila = None   # reparto de filas a recalcular
        self._aplicar_visibilidad()
        self.programar_guardado()
        return pan

    def nueva_pestana(self, url=None, peso=None, activar=True, pos=None):
        """Panel web nuevo."""
        v = Vista(self)
        cont = PanelFlujo(self, v)
        return self._registrar_panel(Pestaña(cont, vista=v),
                                     url=url, peso=peso, activar=activar,
                                     pos=pos)

    def nueva_pestana_app(self, comando, peso=None, activar=True, pos=None):
        """Panel que embebe la ventana de un programa externo (solo X11)."""
        comando = (comando or "").strip()
        if not comando:
            return None
        app = PanelApp(self, comando)
        cont = PanelFlujo(self, app, titulo=comando)
        pan = self._registrar_panel(Pestaña(cont, app=app),
                                    peso=peso, activar=activar, pos=pos)
        app._pan = pan
        app.installEventFilter(self)
        return pan

    def dividir(self, lado="der", comando=None):
        """Comando de división: abre un panel NUEVO junto al panel activo
        (a la derecha/izquierda o arriba/abajo) y deja la barra de direcciones
        enfocada para cargar algo de inmediato. Con `comando`, el panel nuevo
        embebe la ventana de esa aplicación (solo X11)."""
        i = self.tabs.currentIndex()
        if not (0 <= i < len(self.pestañas)):
            i = len(self.pestañas) - 1
        pos = i + 1 if lado in ("der", "aba") else max(i, 0)
        if comando:
            pan = self.nueva_pestana_app(comando, pos=pos)
        else:
            pan = self.nueva_pestana(pos=pos)
        if pan is None:
            return None
        # Si estamos en pestaña única, mostrar la división al instante.
        if self.disposicion == "n":
            self.fijar_disposicion(self.ultima_div)
        # Listo para cargar: foco en la barra de direcciones.
        self.dir.setFocus()
        self.dir.selectAll()
        self.statusBar().showMessage(
            "Panel nuevo: escribe una dirección o URL y pulsa Enter "
            "(Ctrl+K para la paleta)", 5000)
        return pan

    def _pedir_app(self, lado=None):
        try:
            from PyQt6.QtWidgets import QInputDialog
        except ImportError:
            from PyQt5.QtWidgets import QInputDialog
        texto, ok = QInputDialog.getText(
            self, "Panel de aplicación",
            "Comando a embeber (p. ej.:  btop · kwrite · code):")
        if ok and texto.strip():
            if lado:
                self.dividir(lado, comando=texto.strip())
            else:
                self.nueva_pestana_app(texto.strip())

    def cerrar_pestana(self, i):
        if not (0 <= i < len(self.pestañas)):
            return
        if len(self.pestañas) == 1:
            # Nunca dejar la ventana sin paneles: reiniciar el único.
            pan = self.pestañas[0]
            if pan.vista is not None:
                pan.vista.load(QUrl(INICIO))
            return
        pan = self.pestañas.pop(i)
        self.tabs.removeTab(i)
        if pan.app is not None:
            pan.app.cerrar()
        p = pan.contenedor
        p.setParent(None)     # el contenido (hija del panel) se destruye con él
        p.deleteLater()
        self.flujo.layout().alturas_fila = None
        self.programar_guardado()

    def _pestana_movida(self, a, b):
        self.pestañas[a], self.pestañas[b] = self.pestañas[b], self.pestañas[a]
        self._recolocar_paneles()
        self.programar_guardado()

    def _cambio_pestana(self, _i):
        self._aplicar_visibilidad()
        pan = self._panel_activo()
        if pan is not None:
            self.dir.setText(pan.direccion)
            t = pan.titulo
            self.setWindowTitle(f"{t} — MiniBrowser" if t else "MiniBrowser")
        self.programar_guardado()

    def _actualizar_titulo(self, pan):
        try:
            i = next(idx for idx, p in enumerate(self.pestañas) if p is pan)
        except StopIteration:
            return
        t = pan.titulo or "Nueva pestaña"
        self.tabs.setTabText(i, t)
        self.tabs.setTabToolTip(i, t)
        pan.contenedor.titulo.setText(t)
        if i == self.tabs.currentIndex():
            self.setWindowTitle(f"{t} — MiniBrowser" if t else "MiniBrowser")

    def eventFilter(self, obj, ev):
        # Hacer clic en un panel (web o app) lo convierte en el panel activo:
        # subimos por la jerarquía de padres hasta reconocer el contenido.
        if ev.type() == FOCUS_IN:
            i = self._indice_widget(obj)
            if i >= 0 and i != self.tabs.currentIndex():
                self.tabs.setCurrentIndex(i)
        return super().eventFilter(obj, ev)

    def _indice_widget(self, obj):
        w = obj
        while w is not None:
            for i, pan in enumerate(self.pestañas):
                if pan.vista is w or pan.app is w:
                    return i
            w = w.parent()
        return -1

    # ---------- disposiciones de los paneles ----------

    def fijar_disposicion(self, d):
        if d not in ("n", "h", "v", "f"):
            d = "n"
        if d != "n":
            self.ultima_div = d
        self.disposicion = d
        for k, a in self.acc_disp.items():
            a.setChecked(k == d)
        if d in ("h", "v"):
            self.splitter.setOrientation(ORIENT_H if d == "h" else ORIENT_V)
        self._recolocar_paneles()
        self.apilado_host.setCurrentIndex(1 if d == "f" else 0)
        self._aplicar_visibilidad()
        if d in ("h", "v"):
            QTimer.singleShot(0, self._igualar_tamanos)
        self.programar_guardado()

    def alternar_division(self):
        if self.disposicion == "n":
            self.fijar_disposicion(self.ultima_div)
        else:
            self.fijar_disposicion("n")

    def fijar_peso(self, panel, peso):
        """Ancho relativo (flex-basis) de un panel en la disposición flujo."""
        panel.peso = max(0.1, min(1.0, float(peso)))
        if self.disposicion == "f":
            self.flujo.layout().update()
        self.programar_guardado()

    def _peso_activo(self, peso):
        pan = self._panel_activo()
        if pan is not None:
            self.fijar_peso(pan.contenedor, peso)

    def _recolocar_paneles(self):
        """Mueve los contenedores al destino de la disposición actual
        (QSplitter para n/h/v, FlujoLayout para f), conservando el orden."""
        for pan in self.pestañas:
            p = pan.contenedor
            if self.disposicion == "f":
                if p.parent() is not self.flujo:
                    p.setParent(None)
                    self.flujo.layout().addWidget(p)
            else:
                if p.parent() is not self.splitter:
                    p.setParent(None)
                    self.splitter.addWidget(p)

    def _aplicar_visibilidad(self):
        # Disposición normal: solo la pestaña activa es visible.
        # El resto (h/v/f): todos los paneles a la vez, en secuencia.
        activa = self.tabs.currentIndex()
        for i, pan in enumerate(self.pestañas):
            pan.contenedor.setVisible(self.disposicion != "n" or i == activa)

    def _igualar_tamanos(self):
        if self.disposicion in ("h", "v") and self.pestañas:
            self.splitter.setSizes([100] * len(self.pestañas))

    # ---------- navegación ----------

    def _navegar(self, metodo):
        pan = self._panel_activo()
        if pan is not None and pan.vista is not None:
            getattr(pan.vista, metodo)()

    def _url_cambiada(self, url):
        for i, pan in enumerate(self.pestañas):
            if pan.vista is self.sender():
                if i == self.tabs.currentIndex() and not self.dir.hasFocus():
                    self.dir.setText(url.toString())
                break
        self.programar_guardado()

    def _registrar_historial(self, url):
        s = url.toString()
        if s and s != "about:blank" and (not self.historial or self.historial[-1] != s):
            self.historial.append(s)
            if len(self.historial) > 5000:      # tope de memoria, por si acaso
                del self.historial[:1000]

    def _abrir_texto(self, texto):
        """Busca o abre la dirección dada en el panel activo (web)."""
        texto = (texto or "").strip()
        if not texto:
            return
        es_url = "://" in texto or (
            " " not in texto
            and re.match(r"^(localhost(:\d+)?(/.*)?|[\w.-]+\.[A-Za-z]{2,}(:\d+)?(/.*)?)$", texto)
        )
        url = QUrl.fromUserInput(texto) if es_url else QUrl(SEARCH + quote_plus(texto))
        pan = self._panel_activo()
        if pan is not None and pan.vista is not None:
            pan.vista.load(url)
        else:
            self.nueva_pestana(url.toString())

    # ---------- paleta de comandos (tipo KRunner) ----------

    def _acciones_paleta(self):
        pan = self._panel_activo()
        acciones = [
            ("Nueva pestaña", lambda: self.nueva_pestana()),
            ("Nueva pestaña de aplicación (embeber terminal, editor…)",
             lambda: self._pedir_app()),
            ("Dividir: panel nuevo a la derecha del activo (Ctrl+Shift+H)",
             lambda: self.dividir("der")),
            ("Dividir: panel nuevo debajo del activo (Ctrl+Shift+V)",
             lambda: self.dividir("aba")),
            ("Dividir: panel nuevo a la izquierda del activo",
             lambda: self.dividir("izq")),
            ("Dividir: panel nuevo encima del activo",
             lambda: self.dividir("arr")),
            ("Dividir: panel nuevo con aplicación embebida (derecha)",
             lambda: self._pedir_app("der")),
            ("Cerrar panel activo", lambda: self.cerrar_pestana(self.tabs.currentIndex())),
            ("Recargar", lambda: self._navegar("reload")),
            ("Atrás", lambda: self._navegar("back")),
            ("Adelante", lambda: self._navegar("forward")),
            ("Disposición: pestaña única", lambda: self.fijar_disposicion("n")),
            ("Disposición: secuencial horizontal", lambda: self.fijar_disposicion("h")),
            ("Disposición: secuencial vertical", lambda: self.fijar_disposicion("v")),
            ("Disposición: flujo (flex-wrap)", lambda: self.fijar_disposicion("f")),
            ("Alternar vista dividida", self.alternar_division),
            ("Panel siguiente (Ctrl+Tab)", self._panel_siguiente),
            ("Panel anterior (Ctrl+Shift+Tab)", self._panel_anterior),
            ("Foco: izquierda (Ctrl+Alt+Left)",
             lambda: self._foco_direccion(-1, 0)),
            ("Foco: derecha (Ctrl+Alt+Right)",
             lambda: self._foco_direccion(1, 0)),
            ("Foco: arriba (Ctrl+Alt+Up)",
             lambda: self._foco_direccion(0, -1)),
            ("Foco: abajo (Ctrl+Alt+Down)",
             lambda: self._foco_direccion(0, 1)),
            ("Borrar historial", self.borrar_historial),
            ("Borrar cookies y caché", self.borrar_cookies_cache),
            ("Borrar sesión guardada", self.borrar_sesion_guardada),
            ("Salir", self.close),
        ]
        if pan is not None:
            for etiqueta, peso in (("25 %", 0.25), ("33 %", 1 / 3),
                                   ("50 %", 0.5), ("66 %", 2 / 3),
                                   ("75 %", 0.75), ("100 %", 1.0)):
                acciones.append((f"Ancho del panel activo: {etiqueta}",
                                 lambda _, p=peso: self._peso_activo(p)))
        return acciones

    def abrir_paleta(self):
        paleta = Paleta(self, self._acciones_paleta())
        paleta.resize(540, 380)
        g = self.geometry()
        paleta.move(g.center().x() - 270, g.center().y() - 190)
        paleta.entrada.setFocus()
        paleta.exec()

    # ---------- borrado (menú) ----------

    def borrar_historial(self):
        """Borra los enlaces visitados del perfil y el registro propio de
        URLs de esta sesión (todo estaba en RAM, nada persistente)."""
        self.historial.clear()
        self.perfil.clearAllVisitedLinks()
        self.statusBar().showMessage(
            "Historial borrado: enlaces visitados de esta sesión.", 5000)

    def borrar_cookies_cache(self):
        self.perfil.cookieStore().deleteAllCookies()
        self.perfil.clearHttpCache()
        self.statusBar().showMessage("Cookies y caché borrados.", 5000)

    def borrar_sesion_guardada(self):
        try:
            os.remove(self.ruta_sesion)
        except OSError:
            pass
        self.statusBar().showMessage(
            "Sesión guardada borrada; la próxima arrancada abrirá la página de inicio.", 5000)

    # ---------- sesión ("abrir como se dejó") ----------

    def programar_guardado(self):
        if GUARDAR_SESION:
            self._guardar_timer.start(1500)

    def guardar_sesion(self):
        """Guarda SOLO: paneles (URL web o comando de la app, con su ancho
        relativo), panel activo y disposición. Nunca cookies ni historial."""
        if not GUARDAR_SESION:
            return
        paneles = []
        for pan in self.pestañas:
            peso = round(pan.contenedor.peso, 3)
            if pan.vista is not None:
                u = pan.vista.url().toString()
                if u:
                    paneles.append({"tipo": "web", "url": u, "peso": peso})
            elif pan.app is not None:
                paneles.append({"tipo": "app", "comando": pan.app.comando,
                                "peso": peso})
        datos = {
            "paneles": paneles,
            "activa": self.tabs.currentIndex(),
            "disposicion": self.disposicion,
        }
        try:
            os.makedirs(os.path.dirname(self.ruta_sesion), exist_ok=True)
            tmp = self.ruta_sesion + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(datos, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.ruta_sesion)     # escritura atómica
        except OSError:
            pass

    def closeEvent(self, _e):
        self.guardar_sesion()


def cargar_sesion(ruta):
    """Lee la sesión guardada (solo URLs/comandos, anchos y disposición).
    Acepta también formatos antiguos (lista plana de URLs o dicts sin tipo)."""
    if not GUARDAR_SESION or not os.path.isfile(ruta):
        return None
    try:
        with open(ruta, encoding="utf-8") as f:
            datos = json.load(f)
        entradas = datos.get("paneles")
        if not isinstance(entradas, list):
            entradas = datos.get("pestañas")
        paneles = []
        if isinstance(entradas, list):
            for e in entradas[:30]:
                e = {"tipo": "web", "url": e, "peso": 0.5} if isinstance(e, str) else e
                if not isinstance(e, dict):
                    continue
                peso = e.get("peso", 0.5)
                peso = peso if isinstance(peso, (int, float)) else 0.5
                peso = max(0.1, min(1.0, float(peso)))
                if e.get("tipo") == "app":
                    c = e.get("comando")
                    if isinstance(c, str) and c.strip():
                        paneles.append({"tipo": "app", "comando": c.strip(), "peso": peso})
                else:
                    u = e.get("url")
                    if isinstance(u, str) and u:
                        paneles.append({"tipo": "web", "url": u, "peso": peso})
        if not paneles:
            return None
        activa = datos.get("activa", 0)
        if not isinstance(activa, int):
            activa = 0
        disposicion = datos.get("disposicion", "n")
        if disposicion not in ("n", "h", "v", "f"):
            disposicion = "n"
        return {"paneles": paneles, "activa": activa, "disposicion": disposicion}
    except (OSError, ValueError):
        return None


def descargar(item):
    """Descargas: aceptar con la ruta por defecto (~/Descargas)."""
    try:
        item.accept()
    except Exception:
        pass


def crear_perfil():
    """Perfil off-the-record: QWebEngineProfile() sin storageName => incógnito.
    Qt garantiza para perfiles OTR: sin cookies persistentes, sin historial,
    caché solo en memoria. No hace falta setear enums explícitamente, y los
    nombres de esos enums cambiaron entre versiones de PyQt6-WebEngine
    (HttpCacheType.Memory / MemoryHttpCache / etc.) — mejor evitarlos."""
    p = QWebEngineProfile()
    try:
        p.downloadRequested.connect(descargar)
    except AttributeError:
        # Algunas versiones exponen la señal solo en QWebEngineDownloadRequest
        pass
    return p


def limpiar(perfil):
    """Al salir: borrar cookies, enlaces visitados y caché (cinturón y tirantes)."""
    perfil.cookieStore().deleteAllCookies()
    perfil.clearAllVisitedLinks()
    perfil.clearHttpCache()


def main():
    # --selftest: construir la ventana completa SIN mostrarla y salir con 0.
    # Lo usa install.sh para verificar que el arranque real funciona.
    selftest = "--selftest" in sys.argv

    try:
        QApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)          # PyQt5
    except AttributeError:
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts, True)

    app = QApplication(sys.argv)
    app.setApplicationName("minibrowser")
    if hasattr(app, "setDesktopFileName"):
        app.setDesktopFileName("minibrowser")   # casa con el .desktop
    app.setWindowIcon(icono())

    perfil = crear_perfil()
    ventana = Ventana(perfil)
    if selftest:
        ventana.close()
        print("selftest OK: Qt{} · {} panel(es) · disposición {}".format(
            "6" if QT6 else "5", len(ventana.pestañas), ventana.disposicion))
        return 0
    ventana.show()

    # Limpieza al salir: borrar cookies, caché y enlaces visitados
    app.aboutToQuit.connect(lambda: limpiar(perfil))

    sys.exit(app.exec())


def _volcar_error(tipo, valor, tb):
    """Última red de seguridad: si algo revienta antes de que la ventana
    exista, el error queda escrito en ~/.local/state/minibrowser/error.log
    (y en stderr). Así «no abre» nunca se queda sin explicación."""
    import traceback
    texto = "".join(traceback.format_exception(tipo, valor, tb))
    sys.stderr.write(texto)
    try:
        os.makedirs(os.path.dirname(ruta_sesion()), exist_ok=True)
        with open(os.path.join(os.path.dirname(ruta_sesion()), "error.log"),
                  "a", encoding="utf-8") as f:
            f.write("\n----- " + time.strftime("%Y-%m-%d %H:%M:%S") +
                    " -----\n" + texto)
    except OSError:
        pass


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except BaseException:
        _volcar_error(*sys.exc_info())
        raise

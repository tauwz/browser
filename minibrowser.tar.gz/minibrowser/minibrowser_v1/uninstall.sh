#!/bin/bash
# =============================================================================
# uninstall.sh — Desinstalación LIMPIA de MiniBrowser (openSUSE + KDE)
#
# Uso:
#   sudo ./uninstall.sh            # desinstala el programa
#   sudo ./uninstall.sh --datos    # además borra la sesión guardada y logs
#
# Quita TODO lo que instaló install.sh:
#   1. /opt/minibrowser/                    (script + icono)
#   2. /usr/bin/minibrowser                 (enlace simbólico)
#   3. /usr/share/applications/minibrowser.desktop
#   4. /usr/share/icons/hicolor/scalable/apps/minibrowser.svg
#   5. (~/.local/state/minibrowser/)        solo con --datos
#
# NO desinstala los paquetes PyQt/xdotool (otros programas pueden usarlos);
# al final se muestra el comando para hacerlo voluntariamente.
# =============================================================================

set -euo pipefail

C_ROJO='\033[0;31m'; C_VERDE='\033[0;32m'; C_AMAR='\033[1;33m'; C_AZUL='\033[0;34m'; C_OFF='\033[0m'
log()  { echo -e "${C_AZUL}==>${C_OFF} $*"; }
ok()   { echo -e "    ${C_VERDE}OK${C_OFF}  $*"; }
warn() { echo -e "    ${C_AMAR}AVISO${C_OFF} $*"; }
err()  { echo -e "    ${C_ROJO}ERROR${C_OFF} $*" >&2; }

BORRAR_DATOS=0
[[ "${1:-}" == "--datos" ]] && BORRAR_DATOS=1

# ---------- 0. Root ----------
if [[ $EUID -ne 0 ]]; then
    err "Ejecuta con sudo:  sudo ./uninstall.sh"
    exit 1
fi

# Home del usuario real (aunque se ejecute con sudo).
HOME_REAL="$(getent passwd "${SUDO_USER:-$(logname 2>/dev/null || echo root)}" | cut -d: -f6)"
[[ -z "${HOME_REAL}" ]] && HOME_REAL="/root"

log "Deteniendo MiniBrowser si está abierto..."
pkill -f "/opt/minibrowser/minibrowser.py" 2>/dev/null \
    && ok "Proceso detenido" || ok "No estaba en ejecución"

# ---------- 1. Archivos instalados ----------
log "Borrando archivos instalados..."
rm -rf /opt/minibrowser                && ok "Borrado /opt/minibrowser/"
rm -f  /usr/bin/minibrowser            && ok "Borrado /usr/bin/minibrowser"
rm -f  /usr/share/applications/minibrowser.desktop \
                                       && ok "Borrado minibrowser.desktop"
rm -f  /usr/share/icons/hicolor/scalable/apps/minibrowser.svg \
                                       && ok "Borrado icono hicolor"

# ---------- 2. Datos de usuario (opcional) ----------
if [[ "${BORRAR_DATOS}" -eq 1 ]]; then
    log "Borrando datos de usuario (${HOME_REAL}/.local/state/minibrowser)..."
    rm -rf "${HOME_REAL}/.local/state/minibrowser" \
        && ok "Borrada la sesión guardada y el registro de errores"
    # Restos de QWebEngine en caché del usuario (perfil OTR, por si quedaron)
    rm -rf "${HOME_REAL}/.local/share/minibrowser" 2>/dev/null || true
    rm -rf "${HOME_REAL}/.cache/minibrowser" 2>/dev/null || true
    ok "Datos de MiniBrowser eliminados"
else
    warn "Sesión guardada conservada en:"
    warn "  ${HOME_REAL}/.local/state/minibrowser/sesion.json"
    warn "Para borrarla también:  sudo ./uninstall.sh --datos"
fi

# ---------- 3. Actualizar cachés ----------
log "Actualizando cachés del escritorio..."
gtk-update-icon-cache -f -t /usr/share/icons/hicolor 2>/dev/null \
    || warn "gtk-update-icon-cache no disponible (no crítico)."
update-desktop-database /usr/share/applications 2>/dev/null \
    || warn "update-desktop-database no disponible (no crítico)."

# ---------- 4. Comprobación final ----------
echo
if [[ -e /usr/bin/minibrowser || -d /opt/minibrowser ]]; then
    err "Quedan restos de MiniBrowser. Revisa manualmente:"
    err "  /opt/minibrowser  /usr/bin/minibrowser"
else
    ok "MiniBrowser desinstalado por completo."
fi
echo
log "Opcional: quitar las dependencias (SOLO si nada más las usa):"
echo "    sudo zypper remove python3-PyQt6 python3-PyQt6-WebEngine xdotool"
echo "    sudo zypper remove python3-qt5 python3-qtwebengine-qt5"
echo
log "Volver a instalar:  sudo ./install.sh   (junto a minibrowser.py)"
